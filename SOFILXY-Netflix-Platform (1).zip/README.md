# SOFILXY - Netflix Style Movie Platform

This is the full production-ready version of the SOFILXY movie app.