# SOFILXY 🎬

Netflix-style movie app. Deploy on Vercel.

## Steps:
1. Rename `.env.example` to `.env.local`
2. Run `npm install`
3. `npm run dev` to start local server.
