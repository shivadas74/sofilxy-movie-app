
export default function Home() {
  return (
    <div style={{ color: '#fff', backgroundColor: '#000', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <h1>🎬 Welcome to SOFILXY - A Netflix-style Movie App</h1>
    </div>
  );
}
